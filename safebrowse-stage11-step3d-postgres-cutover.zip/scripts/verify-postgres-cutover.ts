#!/usr/bin/env ts-node

/**
 * SafeBrowse Static Cutover Gate
 *
 * Verifies that NO production backend code (packages/backend/src)
 * imports or references the JSON datastore (db singleton or store.ts).
 *
 * Exits 0 if clean, 1 if any prohibited imports or accesses are found.
 */

import fs from 'fs';
import path from 'path';

const srcDir = path.resolve(__dirname, '../packages/backend/src');

interface Violation {
  file: string;
  line: number;
  content: string;
}

const violations: Violation[] = [];

// Allowed patterns: NONE in packages/backend/src
const PROHIBITED_PATTERNS = [
  /from\s+['"].*\/db\/store(\.ts)?['"]/,
  /from\s+['"].*store\.legacy['"]/,
  /\bimport\s+.*\bdb\b.*from/,
  /\bdb\.(users|userSessions|families|familyMembers|children|devices|policies|accessRequests|childUsage|activityEvents|familyAuditLogs|systemAuditLogs|passwordResetTokens|emailVerificationTokens|mfaChallenges|referrals|pairingCodes|feedback|supportTickets)\b/,
  /\bdb\.save\(\)/,
  /\bdb\.load\(\)/,
  /\bdb\.runWithLock/,
  /\bdb\.createFamilySnapshot/,
];

function scanDirectory(dir: string) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      scanDirectory(fullPath);
    } else if (entry.isFile() && (entry.name.endsWith('.ts') || entry.name.endsWith('.js'))) {
      // Do not scan store.ts itself (it is the legacy fixture)
      if (entry.name === 'store.ts' || entry.name === 'store.legacy.ts') {
        continue;
      }

      const fileContent = fs.readFileSync(fullPath, 'utf8');
      const lines = fileContent.split('\n');

      lines.forEach((lineText, idx) => {
        // Skip comment lines
        const trimmed = lineText.trim();
        if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) {
          return;
        }

        for (const pattern of PROHIBITED_PATTERNS) {
          if (pattern.test(lineText)) {
            violations.push({
              file: path.relative(path.resolve(__dirname, '..'), fullPath),
              line: idx + 1,
              content: trimmed,
            });
            break;
          }
        }
      });
    }
  }
}

console.log('===============================================================');
console.log('SafeBrowse PostgreSQL Static Cutover Verification');
console.log(`Scanning: ${path.relative(path.resolve(__dirname, '..'), srcDir)}`);
console.log('===============================================================\n');

scanDirectory(srcDir);

if (violations.length > 0) {
  console.error(`❌ Prohibited JSON DataStore references detected in ${violations.length} location(s):`);
  violations.forEach((v) => {
    console.error(`  - ${v.file}:${v.line} -> ${v.content}`);
  });
  console.error('\nFAIL: Production backend code must strictly use PostgreSQL/Prisma without JSON DataStore dependencies.');
  process.exit(1);
} else {
  console.log('✅ Static Cutover Gate PASSED: Zero JSON DataStore imports or usages in production backend code.');
  process.exit(0);
}
