import { describe, it, before, after } from 'node:test';
import assert from 'node:assert';
import http from 'node:http';
import { app, bootstrap } from '../src/server';
import { prisma } from '../src/db/prisma';
import { nanoid } from 'nanoid';
import {
  generateBase32Secret,
  getCurrentTotpTimeStep,
  generateTotpAtStep,
} from '../src/utils/security';

describe('SafeBrowse Stage 11 Step 3D: Real PostgreSQL API Integration & E2E Suite', () => {
  let server: http.Server;
  let baseUrl: string;
  let port: number;

  const testPassword = 'StrongPassphrase2026!PostgresE2E';
  let parentEmail: string;
  let parentName = 'Primary Parent';
  let parentUserId: string;
  let accessToken: string;
  let refreshToken: string;
  let verificationToken: string;

  let familyId: string;
  let childId: string;
  let deviceId: string;
  let deviceToken: string;
  let pairingCode: string;
  let requestId: string;

  let coParentEmail: string;
  let coParentUserId: string;
  let coParentAccessToken: string;
  let inviteToken: string;

  let mfaSecret: string;
  let recoveryCodes: string[];

  // HTTP Helper using fetch
  const api = async (
    method: string,
    endpoint: string,
    body?: any,
    token?: string
  ): Promise<{ status: number; data: any; headers: Headers }> => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const res = await fetch(`${baseUrl}${endpoint}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    let data: any;
    const text = await res.text();
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }

    return { status: res.status, data, headers: res.headers };
  };

  before(async () => {
    // Start real Express server via bootstrap with port 0
    const rawServer = http.createServer(app);
    server = await bootstrap(app, rawServer, { port: 0, skipListen: false });
    const address = server.address() as any;
    port = address.port;
    baseUrl = `http://127.0.0.1:${port}`;
  });

  after(async () => {
    if (server) {
      await new Promise<void>((resolve) => server.close(() => resolve()));
    }
  });

  // 1. Complete parent registration
  it('1. should register a new parent account via real HTTP API', async () => {
    parentEmail = `parent-${nanoid(8).toLowerCase()}@safebrowse.io`;
    const res = await api('POST', '/api/auth/register', {
      email: parentEmail,
      password: testPassword,
      name: parentName,
      consentVersion: '1.0.0',
    });

    assert.strictEqual(res.status, 200);
    assert.ok(res.data.accessToken);
    assert.ok(res.data.refreshToken);
    assert.strictEqual(res.data.emailVerificationPending, true);
    assert.strictEqual(res.data.user.email, parentEmail);
    assert.ok(res.data.emailVerificationToken);

    parentUserId = res.data.user.id;
    accessToken = res.data.accessToken;
    refreshToken = res.data.refreshToken;
    verificationToken = res.data.emailVerificationToken;
  });

  // 2. Immediate login before verification
  it('2. should permit immediate login before email verification with pending status', async () => {
    const res = await api('POST', '/api/auth/login', {
      email: parentEmail,
      password: testPassword,
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.emailVerificationPending, true);
    assert.ok(res.data.accessToken);
  });

  // 3. Email verification link redemption
  it('3. should verify email address via single-use token', async () => {
    const res = await api('POST', '/api/auth/verify-email', {
      token: verificationToken,
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.success, true);

    // Assert token cannot be re-used
    const replayRes = await api('POST', '/api/auth/verify-email', {
      token: verificationToken,
    });
    assert.strictEqual(replayRes.status, 400);
  });

  // 4. Post-verification login
  it('4. should confirm emailVerified is true on subsequent login', async () => {
    const res = await api('POST', '/api/auth/login', {
      email: parentEmail,
      password: testPassword,
    });

    assert.strictEqual(res.status, 200);
    assert.strictEqual(res.data.emailVerificationPending, false);
    assert.strictEqual(res.data.user.emailVerified, true);
    accessToken = res.data.accessToken;
    refreshToken = res.data.refreshToken;
  });

  // 5. Session refresh rotation
  it('5. should rotate refresh tokens atomically on valid refresh call', async () => {
    const oldRefreshToken = refreshToken;
    const res = await api('POST', '/api/auth/refresh', {
      refreshToken: oldRefreshToken,
    });

    assert.strictEqual(res.status, 200);
    assert.ok(res.data.accessToken);
    assert.ok(res.data.refreshToken);
    assert.notStrictEqual(res.data.refreshToken, oldRefreshToken);

    accessToken = res.data.accessToken;
    refreshToken = res.data.refreshToken;

    // 6. Replay attack rejection & family session revocation
    const replayRes = await api('POST', '/api/auth/refresh', {
      refreshToken: oldRefreshToken,
    });

    assert.strictEqual(replayRes.status, 401);

    // The entire session family should now be revoked
    const postReplayUse = await api('POST', '/api/auth/refresh', {
      refreshToken,
    });
    assert.strictEqual(postReplayUse.status, 401);

    // Re-authenticate to get fresh active session
    const reLogin = await api('POST', '/api/auth/login', {
      email: parentEmail,
      password: testPassword,
    });
    console.log('reLogin response:', JSON.stringify(reLogin));
    accessToken = reLogin.data.accessToken;
    refreshToken = reLogin.data.refreshToken;
  });

  // 7. TOTP enrollment & challenge completion
  it('7. should enroll TOTP MFA and verify with initial 6-digit OTP code', async () => {
    const setupRes = await api('POST', '/api/me/mfa/setup', {}, accessToken);
    console.log('setupRes response:', JSON.stringify(setupRes));
    assert.strictEqual(setupRes.status, 200);
    assert.ok(setupRes.data.secret);
    assert.ok(setupRes.data.otpAuthUrl);
    mfaSecret = setupRes.data.secret;

    // Generate valid TOTP code
    const currentStep = getCurrentTotpTimeStep();
    const otpCode = generateTotpAtStep(mfaSecret, currentStep);

    const verifyRes = await api('POST', '/api/me/mfa/verify', { otpCode }, accessToken);
    assert.strictEqual(verifyRes.status, 200);
    assert.ok(verifyRes.data.recoveryCodes);
    assert.strictEqual(verifyRes.data.recoveryCodes.length, 8);
    recoveryCodes = verifyRes.data.recoveryCodes;
  });

  // 8. Recovery-code login & single-use consumption
  it('8. should perform MFA login using single-use recovery code', async () => {
    // Primary login -> yields MFA challenge ticket
    const loginRes = await api('POST', '/api/auth/login', {
      email: parentEmail,
      password: testPassword,
    });

    assert.strictEqual(loginRes.status, 200);
    assert.strictEqual(loginRes.data.mfaRequired, true);
    assert.ok(loginRes.data.mfaTicket);

    const mfaTicket = loginRes.data.mfaTicket;
    const usedCode = recoveryCodes[0];

    const mfaLoginRes = await api('POST', '/api/auth/mfa-login', {
      mfaTicket,
      code: usedCode,
    });

    assert.strictEqual(mfaLoginRes.status, 200);
    assert.ok(mfaLoginRes.data.accessToken);

    // Assert that the used recovery code cannot be reused
    const secondLogin = await api('POST', '/api/auth/login', {
      email: parentEmail,
      password: testPassword,
    });
    const reUsedRes = await api('POST', '/api/auth/mfa-login', {
      mfaTicket: secondLogin.data.mfaTicket,
      code: usedCode,
    });
    assert.strictEqual(reUsedRes.status, 400);

    accessToken = mfaLoginRes.data.accessToken;
    refreshToken = mfaLoginRes.data.refreshToken;
  });

  // 9. TOTP reuse rejection
  it('9. should reject reused TOTP token within the same time window', async () => {
    const step = getCurrentTotpTimeStep();
    const totp = generateTotpAtStep(mfaSecret, step);

    const login1 = await api('POST', '/api/auth/login', {
      email: parentEmail,
      password: testPassword,
    });
    const mfa1 = await api('POST', '/api/auth/mfa-login', {
      mfaTicket: login1.data.mfaTicket,
      code: totp,
    });
    assert.strictEqual(mfa1.status, 200);

    // Attempt second MFA login with exact same TOTP code
    const login2 = await api('POST', '/api/auth/login', {
      email: parentEmail,
      password: testPassword,
    });
    const mfa2 = await api('POST', '/api/auth/mfa-login', {
      mfaTicket: login2.data.mfaTicket,
      code: totp,
    });
    assert.strictEqual(mfa2.status, 400);
    assert.match(mfa2.data.error, /already been used/);

    accessToken = mfa1.data.accessToken;
  });

  // 10. Child profile creation & default policy seeding
  it('10. should create child profile with transactional default policy seeding', async () => {
    // Get family
    const famRes = await api('GET', '/api/family', undefined, accessToken);
    assert.strictEqual(famRes.status, 200);
    familyId = famRes.data.family.id;

    const childRes = await api(
      'POST',
      '/api/children',
      {
        name: 'Aarav',
        age: 9,
        avatar: '🧒',
        familyId,
      },
      accessToken
    );

    assert.strictEqual(childRes.status, 200);
    assert.ok(childRes.data.child.id);
    assert.strictEqual(childRes.data.child.name, 'Aarav');
    assert.ok(childRes.data.policy);
    assert.strictEqual(childRes.data.policy.rules.length, 2);

    childId = childRes.data.child.id;
  });

  // 11. Pairing-code generation & atomic single-use claim
  it('11. should generate pairing code and claim it transactionally', async () => {
    const codeRes = await api(
      'POST',
      '/api/devices/pairing-code',
      {
        childId,
      },
      accessToken
    );

    assert.strictEqual(codeRes.status, 200);
    assert.ok(codeRes.data.code);
    pairingCode = codeRes.data.code;

    const pairRes = await api('POST', '/api/devices/pair', {
      code: pairingCode,
      deviceName: "Aarav's Windows Laptop",
      platform: 'windows',
      agentVersion: '1.0.0',
    });

    assert.strictEqual(pairRes.status, 200);
    assert.ok(pairRes.data.device.id);
    assert.ok(pairRes.data.device.deviceToken);
    deviceId = pairRes.data.device.id;
    deviceToken = pairRes.data.device.deviceToken;

    // Claiming same code again must fail
    const replayPair = await api('POST', '/api/devices/pair', {
      code: pairingCode,
      deviceName: 'Duplicate Device',
      platform: 'windows',
    });
    assert.strictEqual(replayPair.status, 400);
  });

  // 12. Device heartbeat & 4-state health transition
  it('12. should process device heartbeat and report health status', async () => {
    const hbRes = await api('POST', '/api/devices/heartbeat', {
      deviceId,
      deviceToken,
      activePolicyVersion: 1,
      enforcementActive: true,
      platform: 'windows',
      agentVersion: '1.0.0',
    });

    assert.strictEqual(hbRes.status, 200);
    assert.strictEqual(hbRes.data.status, 'ok');
  });

  // 13. Access-request creation, websocket broadcast & approval
  it('13. should create an access request and allow parent to approve it', async () => {
    const rawReqRes = await fetch(`${baseUrl}/api/requests`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-device-id': deviceId,
        'x-device-token': deviceToken,
      },
      body: JSON.stringify({
        childId,
        deviceId,
        domain: 'khanacademy.org',
        reason: 'Homework research',
      }),
    });
    const reqData = (await rawReqRes.json()) as any;

    assert.strictEqual(rawReqRes.status, 200);
    assert.ok(reqData.id);
    assert.strictEqual(reqData.status, 'PENDING');
    requestId = reqData.id;

    // Parent approves request
    const approveRes = await api(
      'POST',
      `/api/requests/${requestId}/resolve`,
      {
        action: 'APPROVE',
        duration: '15m',
      },
      accessToken
    );

    assert.strictEqual(approveRes.status, 200);
    assert.strictEqual(approveRes.data.request.status, 'APPROVED');

    // 14. Immediate policy synchronization to device
    const devicePolicyRes = await api(
      'GET',
      `/api/policies/device/${deviceId}`,
      undefined,
      undefined
    );

    // Fetch policy with device auth headers
    const devReq = await fetch(`${baseUrl}/api/policies/device/${deviceId}`, {
      headers: {
        'x-device-id': deviceId,
        'x-device-token': deviceToken,
      },
    });
    assert.strictEqual(devReq.status, 200);
    const devPolicyData = await devReq.json();
    assert.ok(devPolicyData.policy);
    const hasKhan = devPolicyData.policy.rules.some((r: any) => r.domain === 'khanacademy.org');
    assert.strictEqual(hasKhan, true);
  });

  // 15. Co-parent invitation & acceptance
  it('15. should invite co-parent and accept invitation transactionally', async () => {
    coParentEmail = `coparent-${nanoid(8).toLowerCase()}@safebrowse.io`;

    const inviteRes = await api(
      'POST',
      '/api/family/invitations',
      {
        familyId,
        email: coParentEmail,
        role: 'PARENT',
      },
      accessToken
    );

    assert.strictEqual(inviteRes.status, 200);
    assert.ok(inviteRes.data.invitation);
    inviteToken = inviteRes.data.rawToken || inviteRes.data.invitation.token;

    // Register co-parent
    const coReg = await api('POST', '/api/auth/register', {
      email: coParentEmail,
      password: testPassword,
      name: 'Co Parent',
    });
    assert.strictEqual(coReg.status, 200);
    await api('POST', '/api/auth/verify-email', { token: coReg.data.emailVerificationToken });

    const coLogin = await api('POST', '/api/auth/login', {
      email: coParentEmail,
      password: testPassword,
    });
    coParentUserId = coLogin.data.user.id;
    coParentAccessToken = coLogin.data.accessToken;

    // Accept invitation
    const acceptRes = await api(
      'POST',
      '/api/family/invitations/accept',
      {
        token: inviteToken,
      },
      coParentAccessToken
    );

    assert.strictEqual(acceptRes.status, 200);
    assert.strictEqual(acceptRes.data.familyId, familyId);
    assert.strictEqual(acceptRes.data.role, 'PARENT');
  });

  // 16. Ownership transfer with single-owner invariant
  it('16. should transfer ownership to co-parent with step-up authentication', async () => {
    const step = getCurrentTotpTimeStep();
    const otpCode = generateTotpAtStep(mfaSecret, step);

    const transferRes = await api(
      'POST',
      '/api/family/transfer-ownership',
      {
        familyId,
        newOwnerUserId: coParentUserId,
        password: testPassword,
        otpCode,
      },
      accessToken
    );

    assert.strictEqual(transferRes.status, 200);
    assert.strictEqual(transferRes.data.success, true);

    // Verify exactly one OWNER exists in the family
    const ownerMembers = await prisma.familyMember.findMany({
      where: { familyId, role: 'OWNER' },
    });
    assert.strictEqual(ownerMembers.length, 1);
    assert.strictEqual(ownerMembers[0].userId, coParentUserId);

    const family = await prisma.family.findUnique({ where: { id: familyId } });
    assert.strictEqual(family?.ownerUserId, coParentUserId);
  });

  // 17. Non-owner rejection of restricted mutations
  it('17. should reject owner-only operations when attempted by demoted previous owner', async () => {
    // Previous owner is now PARENT; cannot transfer ownership or change owner role
    const attemptTransfer = await api(
      'POST',
      '/api/family/transfer-ownership',
      {
        familyId,
        newOwnerUserId: parentUserId,
        password: testPassword,
      },
      accessToken
    );

    assert.strictEqual(attemptTransfer.status, 403);
  });

  // 18. Post-restart data persistence & session validity verification
  it('18. should restart HTTP API and confirm complete persistence and session validity', async () => {
    // Shut down running HTTP server
    await new Promise<void>((resolve) => server.close(() => resolve()));

    // Launch a new server instance on an ephemeral port
    const freshRawServer = http.createServer(app);
    server = await bootstrap(app, freshRawServer, { port: 0, skipListen: false });
    const address = server.address() as any;
    port = address.port;
    baseUrl = `http://127.0.0.1:${port}`;

    // Test that co-parent's session token is still valid across the server restart
    const overviewRes = await api('GET', `/api/family?familyId=${familyId}`, undefined, coParentAccessToken);
    assert.strictEqual(overviewRes.status, 200);
    assert.strictEqual(overviewRes.data.family.id, familyId);
    assert.strictEqual(overviewRes.data.family.ownerUserId, coParentUserId);
    assert.strictEqual(overviewRes.data.myRole, 'OWNER');

    // Child and devices still exist and intact
    assert.strictEqual(overviewRes.data.stats.childrenCount, 1);
    assert.strictEqual(overviewRes.data.stats.devicesCount, 1);
  });

  // 19. Unverified user denied through a real product API
  it('19. should deny unverified user from accessing protected family routes', async () => {
    const unverifiedEmail = `unverified-${nanoid(6).toLowerCase()}@safebrowse.io`;
    const regRes = await api('POST', '/api/auth/register', {
      email: unverifiedEmail,
      password: testPassword,
      name: 'Unverified Parent',
    });
    assert.strictEqual(regRes.status, 200);
    const unverifiedToken = regRes.data.accessToken;

    const famRes = await api('GET', '/api/family', undefined, unverifiedToken);
    assert.strictEqual(famRes.status, 403);
    assert.match(famRes.data.error, /verify|verified/i);
  });

  // 20. Parent/device authentication separation
  it('20. should enforce strict parent/device authentication separation', async () => {
    // Calling device-only endpoint with parent JWT (missing device headers) -> 401
    const devEndpointRes = await fetch(`${baseUrl}/api/devices/heartbeat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        deviceId,
        deviceToken: 'invalid-token',
        activePolicyVersion: 1,
        enforcementActive: true,
      }),
    });
    assert.strictEqual(devEndpointRes.status, 401);

    // Calling parent-only endpoint with device credentials -> 401
    const parentEndpointRes = await fetch(`${baseUrl}/api/family`, {
      method: 'GET',
      headers: {
        'x-device-id': deviceId,
        'x-device-token': deviceToken,
      },
    });
    assert.strictEqual(parentEndpointRes.status, 401);
  });

  // 21. System-admin bootstrap protection through HTTP
  it('21. should reject standard parent/owner from system admin operations with 403', async () => {
    const adminRes = await api('GET', '/api/admin/metrics', undefined, coParentAccessToken);
    assert.strictEqual(adminRes.status, 403);
  });

  // 22. Cross-family read and mutation attacks
  it('22. should strictly reject cross-family read and mutation attacks', async () => {
    // Register another independent family (Family B)
    const familyBEmail = `parentb-${nanoid(6).toLowerCase()}@safebrowse.io`;
    const regB = await api('POST', '/api/auth/register', {
      email: familyBEmail,
      password: testPassword,
      name: 'Parent B',
    });
    await api('POST', '/api/auth/verify-email', { token: regB.data.emailVerificationToken });
    const loginB = await api('POST', '/api/auth/login', {
      email: familyBEmail,
      password: testPassword,
    });
    const tokenB = loginB.data.accessToken;

    // Parent B attempts to access children list of Family A
    const crossChildGet = await api('GET', `/api/children?familyId=${familyId}`, undefined, tokenB);
    assert.strictEqual(crossChildGet.status, 403);
    assert.match(crossChildGet.data.error, /belong/i);

    // Parent B attempts to mutate Child A's policy
    const crossPolicyMutate = await api(
      'POST',
      `/api/policies/child/${childId}/rules`,
      { domain: 'attacker-site.com', action: 'ALLOW' },
      tokenB
    );
    assert.strictEqual(crossPolicyMutate.status, 403);
  });

  // 23. Sole-owner deletion protection
  it('23. should protect sole owner from account deletion before ownership transfer', async () => {
    // coParent is now the sole OWNER of familyId
    const delRes = await api(
      'DELETE',
      '/api/me',
      { password: testPassword },
      coParentAccessToken
    );
    assert.strictEqual(delRes.status, 400);
    assert.match(delRes.data.error, /sole owner/i);
  });

  // 24. Database composite foreign key mismatch rejection
  it('24. should reject relational mismatch insertion at database engine level', async () => {
    let foreignKeyViolated = false;
    try {
      // Attempt to create AccessRequest referencing Child A and Device A, but with mismatched familyId
      await prisma.$executeRaw`
        INSERT INTO "AccessRequest" ("id", "familyId", "childId", "deviceId", "domain", "status", "requestedAt")
        VALUES ('req-mismatch-1', 'fam-invalid-999', ${childId}, ${deviceId}, 'malicious.com', 'PENDING'::"RequestStatus", NOW());
      `;
    } catch {
      foreignKeyViolated = true;
    }
    assert.strictEqual(foreignKeyViolated, true);
  });
});
